var Serie = /** @class */ (function () {
    function Serie(id, name, channel, season, image, info, link) {
        this.id = id;
        this.name = name;
        this.channel = channel;
        this.season = season;
        this.image  = image;
        this.info   = info;
        this.link = link;
    }
    return Serie;
}());
export { Serie };
